-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `name` varchar(30) NOT NULL,
  `sequence` bigint(20) DEFAULT NULL,
  `id_plan` bigint(20) DEFAULT NULL,
  `id_set` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_6vp9vyv971d5n2288r1q117f3` (`id_plan`),
  KEY `FK_7gelr7dquurebgv1459m6oxcy` (`id_set`),
  CONSTRAINT `FK_6vp9vyv971d5n2288r1q117f3` FOREIGN KEY (`id_plan`) REFERENCES `plan` (`id`),
  CONSTRAINT `FK_7gelr7dquurebgv1459m6oxcy` FOREIGN KEY (`id_set`) REFERENCES `set_of_tasks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10034 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic`
--

LOCK TABLES `topic` WRITE;
/*!40000 ALTER TABLE `topic` DISABLE KEYS */;
INSERT INTO `topic` VALUES (0,'Tour interativo','Tour',0,1,0),(1,'Soma de números positivos com resultado positivo','Plano de aula 1',1,1,1),(2,'Soma de números positivos com resultado positivo','Plano de aula 2',2,1,2),(3,'Subtração de números positivos com resultado positivo','Plano de aula 3',3,1,3),(4,'Soma de números positivos com resultado negativo','Plano de aula 4',4,1,4),(5,'Subtração de números positivos com resultado negativo','Plano de aula 5',5,1,5),(6,'Revisão (planos 1 ao 5)','Plano de aula 6',6,1,6),(7,'Soma de X negativo com um número positivo com resultado positivo','Plano de aula 7',7,1,7),(8,'Subtração de X negativo com um número positivo com resultado positivo','Plano de aula 8',8,1,8),(9,'Soma de X negativo com um número positivo com resultado negativo','Plano de aula 9',9,1,9),(10,'Subtração de x negativo com um número positivo com resultado negativo','Plano de aula 10',10,1,10),(11,'Revisão (planos 1 ao 10)','Plano de aula 11',11,1,11),(12,'Multiplicação de X por um número positivo com resultado positivo','Plano de aula 12',12,1,12),(13,'Multiplicação de X por um número positivo com resultado negativo','Plano de aula 13',13,1,13),(14,'Multiplicação de X por um número negativo com resultado positivo','Plano de aula 14',14,1,14),(15,'Multiplicação de X por um número negativo com resultado negativo','Plano de aula 15',15,1,15),(16,'Revisão (planos 12 ao 15)','Plano de aula 16',16,1,16),(17,'Divisão positiva de X por um número com resultado positivo','Plano de aula 17',17,1,17),(18,'Divisão positiva de X por um número com resultado negativo','Plano de aula 18',18,1,18),(19,'Divisão negativa de X por um número com resultado positivo','Plano de aula 19',19,1,19),(20,'Divisão negativa de X por um número com resultado negativo','Plano de aula 20',20,1,20),(21,'Revisão (planos 17 ao 20)','Plano de aula 21',21,1,21),(22,'Equação de primeiro grau padrão','Plano de aula 22',22,1,22),(23,'Equação de primeiro grau com coeficiente negativo','Plano de aula 23',23,1,23),(24,'Equação de primeiro grau com vários termos inteiros','Plano de aula 24',24,1,24),(25,'Revisão (Planos 22 ao 24)','Plano de aula 25',25,1,25),(26,'Parênteses','Plano de aula 26',26,1,26),(27,'Propriedade distributiva','Plano de aula 27',27,1,27),(28,'Proporção','Plano de aula 28',28,1,28),(29,'Revisão (planos 26 ao 28)','Plano de aula 29',29,1,29),(30,'Frações simples','Plano de aula 30',30,1,30),(31,'Frações compostas','Plano de aula 31',31,1,31),(32,'Frações compostas e propriedade distributiva','Plano de aula 32',32,1,32),(33,'Revisão (Planos 30 ao 32)','Plano de aula 33',33,1,33),(34,'Simplificação de Frações e Critérios de Divisibilidade','Plano de revisão 1',34,1,34),(35,'Propriedade Distributiva','Plano de revisão 2',35,1,35),(1001,'Soma de X positivo com uma constante resultando em outra constante','Plano de aula 1001',1001,1,1001),(1002,'Soma de X negativo com uma constante resultando em outra constante','Plano de aula 1002',1002,1,1002),(1003,'Multiplicação de X por um número positivo com resultado positivo ou negativo','Plano de aula 1003',1003,1,1003),(1004,'Multiplicação de X por um número negativo com resultado positivo ou negativo','Plano de aula 1004',1004,1,1004),(1005,'Revisão (planos 1001 ao 1004)','Plano de aula 1005',1005,1,1005),(1006,'Divisão positiva de X por um número com resultado positivo ou negativo','Plano de aula 1006',1006,1,1006),(1007,'Divisão de X por um número negativo com resultado positivo ou negativo','Plano de aula 1007',1007,1,1007),(1008,'Equação de primeiro grau padrão','Plano de aula 1008',1008,1,1008),(1009,'Equação de primeiro grau padrão com coeficiente negativo','Plano de aula 1009',1009,1,1009),(4000,'Plano de Aula 4','Equações PATtranslation 4000',4000,1,4000),(5000,'Plano de Aula 1','Equações PATtranslation 5000',5000,1,5000),(6000,'Plano de Aula 1','Equações PATtranslation 6000',6000,1,6000),(7000,'Equacoes do PATtranslation','Equações do PATtranslation',7000,1,7000),(10033,'EyeTracking','Plano de revisão 10000',10033,1,10033);
/*!40000 ALTER TABLE `topic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-21 17:43:24
