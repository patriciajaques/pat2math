CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `type` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(120) NOT NULL,
  `password` longtext NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `id_group` bigint(20) DEFAULT NULL,
  `firstName` varchar(80) DEFAULT NULL,
  `lastName` varchar(80) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `question1` varchar(255) DEFAULT NULL,
  `question2` varchar(255) DEFAULT NULL,
  `question3` varchar(255) DEFAULT NULL,
  `currentLevel` int(11) DEFAULT NULL,
  `currentPlan` int(11) DEFAULT NULL,
  `numEquationsSolved` int(11) DEFAULT NULL,
  `numErrors` int(11) DEFAULT NULL,
  `numHints` int(11) DEFAULT NULL,
  `rewardFinal` tinyint(1) DEFAULT NULL,
  `rewardWorkedExamples` tinyint(1) DEFAULT NULL,
  `scoreLevel1` int(11) DEFAULT NULL,
  `scoreLevel2` int(11) DEFAULT NULL,
  `scoreLevel3` int(11) DEFAULT NULL,
  `scoreLevel4` int(11) DEFAULT NULL,
  `scoreLevel5` int(11) DEFAULT NULL,
  `totalScore` int(11) DEFAULT NULL,
  `tourWasViewed` tinyint(1) DEFAULT NULL,
  `turma` int(11) DEFAULT NULL,
  `notaTeste` double DEFAULT NULL,
  `knowledgeTestWasRealized` tinyint(1) DEFAULT NULL,
  `equationsExam` varchar(255) DEFAULT NULL,
  `idsExam` varchar(255) DEFAULT NULL,
  `isUserTest` tinyint(1) DEFAULT NULL,
  `school_id` bigint(20) DEFAULT NULL,
  `numErrorsLevel1` int(11) DEFAULT NULL,
  `numErrorsLevel2` int(11) DEFAULT NULL,
  `numErrorsLevel3` int(11) DEFAULT NULL,
  `numHintsLevel1` int(11) DEFAULT NULL,
  `numHintsLevel2` int(11) DEFAULT NULL,
  `numHintsLevel3` int(11) DEFAULT NULL,
  `numHintsLevel4` int(11) DEFAULT NULL,
  `numHintsLevel5` int(11) DEFAULT NULL,
  `numHits` int(11) DEFAULT NULL,
  `examHasRealized` tinyint(1) DEFAULT NULL,
  `needsToTakeExam` tinyint(1) DEFAULT NULL,
  `isAdminPAT2Exam` tinyint(1) DEFAULT NULL,
  `equationsPosTest` varchar(255) DEFAULT NULL,
  `equationsPreTest` varchar(255) DEFAULT NULL,
  `idsPosTest` varchar(255) DEFAULT NULL,
  `idsPreTest` varchar(255) DEFAULT NULL,
  `needsToTakePosTest` tinyint(1) DEFAULT NULL,
  `needsToTakePreTest` tinyint(1) DEFAULT NULL,
  `notaPosTeste` double DEFAULT NULL,
  `notaPreTeste` double DEFAULT NULL,
  `posTestHasRealized` tinyint(1) DEFAULT NULL,
  `preTestHasRealized` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  KEY `FK_epa6c9m826hdmrkhwxc98gwyc` (`id_group`),
  KEY `FK_lor9dcg3sfp40pyab8o2kjp6b` (`school_id`),
  CONSTRAINT `FK_epa6c9m826hdmrkhwxc98gwyc` FOREIGN KEY (`id_group`) REFERENCES `_group` (`id`),
  CONSTRAINT `FK_lor9dcg3sfp40pyab8o2kjp6b` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4114 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-18 18:17:08
