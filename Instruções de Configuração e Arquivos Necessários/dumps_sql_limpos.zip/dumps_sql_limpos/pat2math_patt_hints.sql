CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patt_hints`
--

DROP TABLE IF EXISTS `patt_hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patt_hints` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hint` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `id_topic` bigint(20) DEFAULT NULL,
  `id_problem_data` bigint(20) DEFAULT NULL,
  `id_problem_relation` bigint(20) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `id_problem` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_e05e5v67ectsy014gonckxvhd` (`id_topic`),
  KEY `FK_au3ndu5sign9x0s0q6y91s534` (`id_problem_data`),
  KEY `FK_old8tqr9vbqsds3ihq9w8ucbd` (`id_problem_relation`),
  CONSTRAINT `FK_au3ndu5sign9x0s0q6y91s534` FOREIGN KEY (`id_problem_data`) REFERENCES `patt_problem_data` (`id`),
  CONSTRAINT `FK_e05e5v67ectsy014gonckxvhd` FOREIGN KEY (`id_topic`) REFERENCES `patt_problem` (`id`),
  CONSTRAINT `FK_old8tqr9vbqsds3ihq9w8ucbd` FOREIGN KEY (`id_problem_relation`) REFERENCES `patt_problem_relation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1865 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patt_hints`
--

LOCK TABLES `patt_hints` WRITE;
/*!40000 ALTER TABLE `patt_hints` DISABLE KEYS */;
/*!40000 ALTER TABLE `patt_hints` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-18 18:17:05
