CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `currentStep` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `element_clicked` varchar(255) DEFAULT NULL,
  `error_feedback` varchar(255) DEFAULT NULL,
  `error_points` int(11) DEFAULT NULL,
  `got_hint_before` varchar(255) DEFAULT NULL,
  `hint` varchar(255) DEFAULT NULL,
  `hints_last_minute` varchar(255) DEFAULT NULL,
  `hints_per_operation` varchar(255) DEFAULT NULL,
  `idle_log_time` int(11) DEFAULT NULL,
  `idle_seconds` int(11) DEFAULT NULL,
  `idle_server_request_time` int(11) DEFAULT NULL,
  `initial_equation` varchar(255) DEFAULT NULL,
  `isComplete` tinyint(1) DEFAULT NULL,
  `is_pending_log` tinyint(1) DEFAULT NULL,
  `key_pressed` varchar(255) DEFAULT NULL,
  `key_pressed_char` varchar(255) DEFAULT NULL,
  `last_correct_step` varchar(255) DEFAULT NULL,
  `last_log_time` datetime DEFAULT NULL,
  `last_server_request_time` datetime DEFAULT NULL,
  `mouse_screenX` int(11) DEFAULT NULL,
  `mouse_screenY` int(11) DEFAULT NULL,
  `mouse_time_diff` int(11) DEFAULT NULL,
  `mouse_x_diff` int(11) DEFAULT NULL,
  `mouse_x_speed` int(11) DEFAULT NULL,
  `mouse_y_diff` int(11) DEFAULT NULL,
  `mouse_y_speed` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `stepCount` int(11) DEFAULT NULL,
  `step_feedback` varchar(255) DEFAULT NULL,
  `step_is_correct` tinyint(1) DEFAULT NULL,
  `step_is_final` tinyint(1) DEFAULT NULL,
  `system_version` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id_script` int(11) DEFAULT NULL,
  `verified_with` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_8lt309ogyiek75y7v92jvl08j` (`user_id`),
  CONSTRAINT `FK_8lt309ogyiek75y7v92jvl08j` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=226174 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-18 18:17:08
