CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mindfulnessExperience`
--

DROP TABLE IF EXISTS `mindfulnessExperience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mindfulnessExperience` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `exercise` varchar(255) DEFAULT NULL,
  `humor` varchar(255) DEFAULT NULL,
  `q11` int(11) NOT NULL,
  `q12` int(11) NOT NULL,
  `q13` int(11) NOT NULL,
  `q21` int(11) NOT NULL,
  `q22` int(11) NOT NULL,
  `q23` int(11) NOT NULL,
  `q31` int(11) NOT NULL,
  `q32` int(11) NOT NULL,
  `q33` int(11) NOT NULL,
  `q41` int(11) NOT NULL,
  `q42` int(11) NOT NULL,
  `q43` int(11) NOT NULL,
  `q51` int(11) NOT NULL,
  `q52` int(11) NOT NULL,
  `q53` int(11) NOT NULL,
  `q61` int(11) NOT NULL,
  `q62` int(11) NOT NULL,
  `q63` int(11) NOT NULL,
  `q71` int(11) NOT NULL,
  `q72` int(11) NOT NULL,
  `q73` int(11) NOT NULL,
  `experience_time` int(11) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_kf052fen7fyu86gk3dh8pa0ow` (`user_id`),
  CONSTRAINT `FK_kf052fen7fyu86gk3dh8pa0ow` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mindfulnessExperience`
--

LOCK TABLES `mindfulnessExperience` WRITE;
/*!40000 ALTER TABLE `mindfulnessExperience` DISABLE KEYS */;
INSERT INTO `mindfulnessExperience` VALUES (1,'2017-10-19 20:47:18',NULL,NULL,1,0,0,10,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1021),(2,'2017-10-19 20:47:26',NULL,NULL,1,0,0,10,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1021),(3,'2017-10-19 20:47:30','História da matemática','Neutro',1,0,0,10,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1021),(4,'2017-10-19 20:51:31','História da matemática','Neutro',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,8,9,2,3,2,0,1021),(5,'2017-10-19 21:03:07','História da matemática','Neutro',10,0,0,7,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1021),(6,'2017-10-19 22:29:25','História da matemática','Neutro',0,0,0,0,0,0,0,0,0,10,10,10,2,3,3,0,0,0,0,0,0,0,1021);
/*!40000 ALTER TABLE `mindfulnessExperience` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-20  1:57:32
