CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `set_of_tasks`
--

DROP TABLE IF EXISTS `set_of_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `set_of_tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `name` varchar(30) NOT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `school_id` bigint(20) DEFAULT NULL,
  `contents` varchar(255) DEFAULT NULL,
  `numberQuestions` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_6m3yqdsrbn7303w1iqfg8nx0k` (`level_id`),
  KEY `FK_muq8cpcu0ilvgtgw02e2dulbk` (`school_id`),
  CONSTRAINT `FK_6m3yqdsrbn7303w1iqfg8nx0k` FOREIGN KEY (`level_id`) REFERENCES `set_of_tasks_levels` (`id`),
  CONSTRAINT `FK_muq8cpcu0ilvgtgw02e2dulbk` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `set_of_tasks`
--

LOCK TABLES `set_of_tasks` WRITE;
/*!40000 ALTER TABLE `set_of_tasks` DISABLE KEYS */;
INSERT INTO `set_of_tasks` VALUES (0,'Tour interativo','Tour',NULL,NULL,'0,1,2,3,4,5,6,7,8,9,10,11,12,13','14'),(1,'Soma de números positivos com resultado positivo','Plano de aula 1',NULL,NULL,NULL,NULL),(2,'Soma de números positivos com resultado positivo','Plano de aula 2',NULL,NULL,NULL,NULL),(3,'Subtração de números positivos com resultado positivo','Plano de aula 3',NULL,NULL,NULL,NULL),(4,'Soma de números positivos com resultado negativo','Plano de aula 4',NULL,NULL,NULL,NULL),(5,'Subtração de números positivos com resultado negativo','Plano de aula 5',NULL,NULL,NULL,NULL),(6,'Revisão (planos 1 ao 5)','Plano de aula 6',NULL,NULL,NULL,NULL),(7,'Soma de X negativo com um número positivo com resultado positivo','Plano de aula 7',NULL,NULL,NULL,NULL),(8,'Subtração de X negativo com um número positivo com resultado positivo','Plano de aula 8',NULL,NULL,NULL,NULL),(9,'Soma de X negativo com um número positivo com resultado negativo','Plano de aula 9',NULL,NULL,NULL,NULL),(10,'Subtração de x negativo com um número positivo com resultado negativo','Plano de aula 10',NULL,NULL,NULL,NULL),(11,'Revisão (planos 1 ao 10)','Plano de aula 11',NULL,NULL,NULL,NULL),(12,'Multiplicação de X por um número positivo com resultado positivo','Plano de aula 12',NULL,NULL,NULL,NULL),(13,'Multiplicação de X por um número positivo com resultado negativo','Plano de aula 13',NULL,NULL,NULL,NULL),(14,'Multiplicação de X por um número negativo com resultado positivo','Plano de aula 14',NULL,NULL,NULL,NULL),(15,'Multiplicação de X por um número negativo com resultado negativo','Plano de aula 15',NULL,NULL,NULL,NULL),(16,'Revisão (planos 12 ao 15)','Plano de aula 16',NULL,NULL,NULL,NULL),(17,'Divisão positiva de X por um número com resultado positivo','Plano de aula 17',NULL,NULL,NULL,NULL),(18,'Divisão positiva de X por um número com resultado negativo','Plano de aula 18',NULL,NULL,NULL,NULL),(19,'Divisão negativa de X por um número com resultado positivo','Plano de aula 19',NULL,NULL,NULL,NULL),(20,'Divisão negativa de X por um número com resultado negativo','Plano de aula 20',NULL,NULL,NULL,NULL),(21,'Revisão (planos 17 ao 20)','Plano de aula 21',NULL,NULL,NULL,NULL),(22,'Equação de primeiro grau padrão','Plano de aula 22',NULL,NULL,NULL,NULL),(23,'Equação de primeiro grau com coeficiente negativo','Plano de aula 23',NULL,NULL,NULL,NULL),(24,'Equação de primeiro grau com vários termos inteiros','Plano de aula 24',NULL,NULL,NULL,NULL),(25,'Revisão (Planos 22 ao 24)','Plano de aula 25',NULL,NULL,NULL,NULL),(26,'Parênteses','Plano de aula 26',NULL,NULL,NULL,NULL),(27,'Propriedade distributiva','Plano de aula 27',NULL,NULL,NULL,NULL),(28,'Proporção','Plano de aula 28',NULL,NULL,NULL,NULL),(29,'Revisão (planos 26 ao 28)','Plano de aula 29',NULL,NULL,NULL,NULL),(30,'Frações simples','Plano de aula 30',NULL,NULL,NULL,NULL),(31,'Frações compostas','Plano de aula 31',NULL,NULL,NULL,NULL),(32,'Frações compostas e propriedade distributiva','Plano de aula 32',NULL,NULL,NULL,NULL),(33,'Revisão (Planos 30 ao 32)','Plano de aula 33',NULL,NULL,NULL,NULL),(34,'Simplificação de Frações e Critérios de Divisibilidade','Plano de revisão 1',NULL,NULL,NULL,NULL),(35,'Propriedade Distributiva','Plano de revisão 2',NULL,NULL,NULL,NULL),(42,'Season Finale','Plano de aula 42',NULL,NULL,NULL,NULL),(1001,'Soma de X positivo com uma constante resultando em outra constante','Plano de aula 1001',NULL,NULL,NULL,NULL),(1002,'Soma de X negativo com uma constante resultando em outra constante','Plano de aula 1002',NULL,NULL,NULL,NULL),(1003,'Multiplicação de X por um número positivo com resultado positivo ou negativo','Plano de aula 1003',NULL,NULL,NULL,NULL),(1004,'Multiplicação de X por um número negativo com resultado positivo ou negativo','Plano de aula 1004',NULL,NULL,NULL,NULL),(1005,'Revisão (planos 1001 ao 1004)','Plano de aula 1005',NULL,NULL,NULL,NULL),(1006,'Divisão positiva de X por um número com resultado positivo ou negativo','Plano de aula 1006',NULL,NULL,NULL,NULL),(1007,'Divisão de X por um número negativo com resultado positivo ou negativo','Plano de aula 1007',NULL,NULL,NULL,NULL),(1008,'Equação de primeiro grau padrão','Plano de aula 1008',NULL,NULL,NULL,NULL),(1009,'Equação de primeiro grau padrão com coeficiente negativo','Plano de aula 1009',NULL,NULL,NULL,NULL),(1010,'Revisão (planos 1006 ao 1009)','Plano de aula 1010',NULL,NULL,NULL,NULL),(1011,'Equação de primeiro grau com vários termos','Plano de aula 1011',NULL,NULL,NULL,NULL),(1012,'Propriedade Distributiva','Plano de aula 1012',NULL,NULL,NULL,NULL),(1013,'Razão e Proporção','Plano de aula 1013',NULL,NULL,NULL,NULL),(1014,'Revisão (planos 1011 ao 1013)','Plano de aula 1014',NULL,NULL,NULL,NULL),(1015,'Frações simples','Plano de aula 1015',NULL,NULL,NULL,NULL),(1016,'Frações compostas','Plano de aula 1016',NULL,NULL,NULL,NULL),(4000,'Plano de Aula 4','Equações PATtranslation 4000',NULL,NULL,NULL,NULL),(5000,'Plano de Aula 1','Equações PATtranslation 5000',NULL,NULL,NULL,NULL),(6000,'Plano de Aula 6','Equações PATtranslation 6000',NULL,NULL,NULL,NULL),(7000,'Equacoes do PATtranslation','Equações do PATtranslation',NULL,NULL,NULL,NULL),(10033,'EyeTracking','Plano de revisão 10000',NULL,NULL,NULL,NULL),(10034,'Teste','Exemplo',4,2,NULL,NULL),(99999,'PAT2Exam','PAT2Exam',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `set_of_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-18 18:17:04
