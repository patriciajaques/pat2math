CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patt_problem_relation`
--

DROP TABLE IF EXISTS `patt_problem_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patt_problem_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `id_data` bigint(20) DEFAULT NULL,
  `id_problem` bigint(20) DEFAULT NULL,
  `expression` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_fo6k6pvc9il0cgx9w2yy6gaic` (`id_data`),
  KEY `FK_2bbt1pdh477uhdeb57f1fsj3f` (`id_problem`),
  CONSTRAINT `FK_2bbt1pdh477uhdeb57f1fsj3f` FOREIGN KEY (`id_problem`) REFERENCES `patt_problem` (`id`),
  CONSTRAINT `FK_fo6k6pvc9il0cgx9w2yy6gaic` FOREIGN KEY (`id_data`) REFERENCES `patt_problem_data` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patt_problem_relation`
--

LOCK TABLES `patt_problem_relation` WRITE;
/*!40000 ALTER TABLE `patt_problem_relation` DISABLE KEYS */;
INSERT INTO `patt_problem_relation` VALUES (33,'jornais vendidos no domingo',NULL,8,'150+100','r'),(34,NULL,NULL,8,'x=(150+100)+6*150','e'),(39,'',NULL,9,'x=9*136','e'),(40,'Valor dos Cadernos',NULL,10,'3*18','r'),(41,'Custo das borrachas',NULL,10,'2*1','r'),(42,'Custo das Canetas',NULL,10,'6*2.5','r'),(43,'',NULL,10,'x=(3*18)+(2*1)+(6*2.5)','e'),(45,'',NULL,NULL,'x=72+17+25','e'),(46,'',NULL,15,'x=20-5-9','e'),(47,'',NULL,16,'x=15*10','e'),(48,'',NULL,17,'x=336/16','e'),(49,'',NULL,18,'x=46-32','e'),(50,'',NULL,19,'x=3216/3','e'),(51,'',NULL,20,'x=3*5','e'),(52,'custo de 1 metro',NULL,NULL,'10/8','r'),(53,'',NULL,NULL,'x=(10/8)*25','e'),(54,'',NULL,NULL,'x=61/4','e'),(55,'',NULL,23,'x=2660/7','e'),(56,'Valor de Isabela',NULL,NULL,'568.9*3','r'),(57,'',NULL,NULL,'x=(568.9*3)+568.9','e'),(58,'Custo de 2 bonecas',NULL,25,'20*2','r'),(59,'',NULL,25,'x=50-(20*2)','e'),(60,'custo de 2 canetas',NULL,26,'60-24','r'),(61,'',NULL,26,'x=(60-24)/3','e'),(62,'total de piões',NULL,27,'8*26','r'),(63,'',NULL,27,'x=(8*26)-8','e'),(64,'custo de 1 objeto',NULL,NULL,'450/6','r'),(67,'Total em balas',NULL,NULL,'4*0.5','r'),(68,'',NULL,NULL,'20-2.75-2-(4*0.5)','r'),(69,'',NULL,NULL,'x=20-2.75-2-(4*0.5)','e'),(70,'Custo total das creches',NULL,NULL,'3*250','r'),(71,'',NULL,NULL,'x=850-(3*250)','e'),(74,'Calças mais sapatos',NULL,33,'52+72','r'),(75,'',NULL,33,'x=(52+72)-17','e'),(76,'total de passageiros',NULL,34,'47+34','r'),(77,'',NULL,34,'x=(47+34)*2','e'),(78,'livros nas caixas',NULL,35,'8*100','r'),(79,'livros nos pacotes',NULL,35,'5*10','r'),(80,'',NULL,35,'x=(8*100)+(5*10)+9','e'),(81,'valor de cinco centavos',NULL,NULL,'5*0.05','r'),(82,'valor de 10 centavos',NULL,NULL,'8*0.1','r'),(83,'valor de 25 centavos',NULL,NULL,'3*0.25','r'),(84,'',NULL,NULL,'x=(5*0.05)+(8*0.1)+(3*0.25)','e'),(85,'Quilos em 2 sacos de laranja',NULL,37,'5*2','r'),(86,'',NULL,37,'x=750*(5*2)','e'),(87,'total de alunos',NULL,38,'18*34','r'),(88,'',NULL,38,'x=(18*34)/3','e'),(89,'producao por dia',NULL,39,'450+1350','r'),(90,'Producao por 15 dias',NULL,39,'(450+1350)*15','r'),(91,'',NULL,39,'x=((450+1350)*15)/5','e'),(92,'total de lápis',NULL,40,'4*36','r'),(93,'',NULL,40,'x=(4*36)/24','e'),(94,'total em moedas de 25',NULL,41,'10*0.25','r'),(95,'valor total de 10 centavos',NULL,41,'4.3-(10*0.25)','r'),(96,'Total de camas',NULL,42,'34*3','r'),(97,'',NULL,42,'x=(34*3)*2','e'),(98,NULL,NULL,41,'x=(4.3-(10*0.25))/0.1','e'),(99,'Total gasto',NULL,NULL,'(4*0.5)+2.75+2','r'),(100,'',NULL,NULL,'20-((4*0.5)+2.75+2)','r'),(101,'',NULL,NULL,'x=20-((4*0.5)+2.75+2)','e'),(102,'custo de 1 metro',NULL,21,'8/10','r'),(103,'',NULL,21,'x=(8/10)*25','e'),(104,'Valor de Isabela',NULL,24,'525*3','r'),(105,'',NULL,24,'x=(525*3)+525','e'),(106,'picolés',NULL,29,'4*1','r'),(107,'Total gasto',NULL,29,'(4*1)+2+3','r'),(108,'',NULL,29,'x=20-((4*1)+2+3)','e'),(109,'Custo total creches',NULL,31,'250000*3','r'),(110,'',NULL,NULL,'850000-(250000*3)','r'),(111,'',NULL,31,'x=850000-(250000*3)','e'),(112,'',NULL,22,'x=60/4','e'),(113,'',NULL,NULL,'x=25*11','e'),(114,'',NULL,NULL,'x=25*11','e'),(115,'',NULL,43,'x=25*11','e'),(116,'',NULL,44,'x=204/12','e'),(117,'',NULL,NULL,'x=27*4','e'),(118,'Conversão de metro para centímetro',NULL,NULL,'1*100','r'),(119,'',NULL,NULL,'x=(1*100)*60','e'),(120,'',NULL,45,'x=27*4','e'),(121,'',NULL,NULL,'x=(1*100)*60','e'),(122,'Conversão de metro para centímetro',NULL,46,'1*100','r'),(123,'',NULL,46,'x=(1*100)*60','e'),(124,'Lados',NULL,47,'2*540','r'),(125,'Lados',NULL,47,'2*890','r'),(126,'',NULL,47,'x=(2*540)+(2*890)','e'),(127,'',NULL,NULL,'x=200/24','e'),(128,'',NULL,49,'x=17*8','e'),(129,'',NULL,50,'x=522*720','e'),(130,'',NULL,NULL,'2*522','r'),(131,'Lados',NULL,51,'2*522','r'),(132,'Lados',NULL,51,'2*720','r'),(133,'',NULL,51,'x=(2*522)+(2*720)','e'),(134,'Área da piscina',NULL,52,'17*8','r'),(135,'Área do terreno',NULL,52,'522*720','r'),(136,'',NULL,52,'x=(522*720)-(17*8)','e'),(137,'Centímetros escavados por hora',NULL,NULL,'1*24','r'),(138,'Conversão de metro para centímetro',NULL,48,'2*100','r'),(139,'',NULL,48,'x=(2*100)/24','e'),(140,'',NULL,60,'x=900+200+80','e'),(141,'Total de Adesivos',NULL,55,'7*30','r'),(142,'',NULL,55,'x=(7*30)-20','e'),(143,'',NULL,NULL,'15*10','r'),(144,'azulejos na primeira parede',NULL,57,'15*10','r'),(145,'Total de azulejos na segunda parede',NULL,57,'13*10','r'),(146,'',NULL,57,'x=(15*10)+(13*10)','e'),(147,'Total de Bolas de Jeferson e Gabriel',NULL,59,'75+25','r'),(148,'',NULL,59,'x=(75+25)+20','e'),(149,'Horas Adicionais',NULL,58,'5*4','r'),(150,'',NULL,58,'x=10+(5*4)','e'),(151,'',NULL,53,'x=4*5','e'),(152,'Pães vendidos no sábado.',NULL,62,'1250*2','r'),(153,'',NULL,62,'x=1250+1824+(1250*2)','e'),(154,'',NULL,61,'x=80-36-25','e'),(155,'',NULL,54,'x=1872/6','e'),(156,'Custo das canetas.',NULL,56,'1849*3','r'),(157,'Custo dos Lapis',NULL,56,'1044*2','r'),(158,'Custo das borrachas',NULL,56,'828*1','r'),(159,'',NULL,56,'x=(1849*3)+(1044*2)+(828*1)','e'),(160,'Valor restante',NULL,63,'872-272','r'),(161,'',NULL,63,'x=(872-272)/3','e'),(162,'Total de Bolas',NULL,65,'80*3','r'),(163,'Total de Bolas dos Dois',NULL,65,'(80*3)+80','r'),(164,'',NULL,65,'x=((80*3)+80)/16','e'),(165,'Voltas por minuto',NULL,77,'420/14','r'),(166,'',NULL,77,'x=(420/14)*90','e'),(167,'Custo dos cadernos',NULL,64,'120-48','r'),(168,'',NULL,64,'x=(120-48)/6','e'),(169,'',NULL,66,'x=522/18','e'),(170,'',NULL,70,'x=700-89','e'),(171,'Custo dos cadernos',NULL,73,'86-26','r'),(172,'',NULL,73,'x=(86-26)/5','e'),(173,'Custo de 1m de tecido',NULL,68,'19/8','r'),(174,'Custo para Carla',NULL,68,'(19/8)*12','r'),(175,'',NULL,68,'x=19+((19/8)*12)','e'),(176,'Lenços por metro',NULL,69,'300/100','r'),(177,'',NULL,69,'x=(300/100)*175','e'),(178,'Total de Pessoas',NULL,74,'120+5','r'),(179,'',NULL,74,'x=(120+5)/5','e'),(180,'Total de Passageiros',NULL,72,'56+64','r'),(181,'',NULL,72,'x=(56+64)*4','e'),(182,'Valor por pessoa',NULL,67,'85/5','r'),(183,'',NULL,67,'x=(85/5)+18','e'),(184,'',NULL,75,'x=2000/50','e'),(185,'',NULL,71,'x=14-9','e'),(190,'',NULL,14,'x=25+17','e');
/*!40000 ALTER TABLE `patt_problem_relation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-25 18:44:52
