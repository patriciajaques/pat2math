CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `set_of_tasks`
--

DROP TABLE IF EXISTS `set_of_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `set_of_tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7001 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `set_of_tasks`
--

LOCK TABLES `set_of_tasks` WRITE;
/*!40000 ALTER TABLE `set_of_tasks` DISABLE KEYS */;
INSERT INTO `set_of_tasks` VALUES (0,'Tour interativo','Tour'),(1,'Soma de números positivos com resultado positivo','Plano de aula 1'),(2,'Soma de números positivos com resultado positivo','Plano de aula 2'),(3,'Subtração de números positivos com resultado positivo','Plano de aula 3'),(4,'Soma de números positivos com resultado negativo','Plano de aula 4'),(5,'Subtração de números positivos com resultado negativo','Plano de aula 5'),(6,'Revisão (planos 1 ao 5)','Plano de aula 6'),(7,'Soma de X negativo com um número positivo com resultado positivo','Plano de aula 7'),(8,'Subtração de X negativo com um número positivo com resultado positivo','Plano de aula 8'),(9,'Soma de X negativo com um número positivo com resultado negativo','Plano de aula 9'),(10,'Subtração de x negativo com um número positivo com resultado negativo','Plano de aula 10'),(11,'Revisão (planos 1 ao 10)','Plano de aula 11'),(12,'Multiplicação de X por um número positivo com resultado positivo','Plano de aula 12'),(13,'Multiplicação de X por um número positivo com resultado negativo','Plano de aula 13'),(14,'Multiplicação de X por um número negativo com resultado positivo','Plano de aula 14'),(15,'Multiplicação de X por um número negativo com resultado negativo','Plano de aula 15'),(16,'Revisão (planos 12 ao 15)','Plano de aula 16'),(17,'Divisão positiva de X por um número com resultado positivo','Plano de aula 17'),(18,'Divisão positiva de X por um número com resultado negativo','Plano de aula 18'),(19,'Divisão negativa de X por um número com resultado positivo','Plano de aula 19'),(20,'Divisão negativa de X por um número com resultado negativo','Plano de aula 20'),(21,'Revisão (planos 17 ao 20)','Plano de aula 21'),(22,'Equação de primeiro grau padrão','Plano de aula 22'),(23,'Equação de primeiro grau com coeficiente negativo','Plano de aula 23'),(24,'Equação de primeiro grau com vários termos inteiros','Plano de aula 24'),(25,'Revisão (Planos 22 ao 24)','Plano de aula 25'),(26,'Parênteses','Plano de aula 26'),(27,'Propriedade distributiva','Plano de aula 27'),(28,'Proporção','Plano de aula 28'),(29,'Revisão (planos 26 ao 28)','Plano de aula 29'),(30,'Frações simples','Plano de aula 30'),(31,'Frações compostas','Plano de aula 31'),(32,'Frações compostas e propriedade distributiva','Plano de aula 32'),(33,'Revisão (Planos 30 ao 32)','Plano de aula 33'),(34,'Simplificação de Frações e Critérios de Divisibilidade','Plano de revisão 1'),(35,'Propriedade Distributiva','Plano de revisão 2'),(4000,'Plano de Aula 4','Equações PATtranslation 4000'),(5000,'Plano de Aula 1','Equações PATtranslation 5000'),(6000,'Plano de Aula 6','Equações PATtranslation 6000'),(7000,'Equacoes do PATtranslation','Equações do PATtranslation');
/*!40000 ALTER TABLE `set_of_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-21 16:04:50
