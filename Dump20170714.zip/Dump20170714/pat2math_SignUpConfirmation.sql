CREATE DATABASE  IF NOT EXISTS `pat2math` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pat2math`;
-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pat2math
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SignUpConfirmation`
--

DROP TABLE IF EXISTS `SignUpConfirmation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SignUpConfirmation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_svanflaqftu1nycobjhe019h` (`user_id`),
  CONSTRAINT `FK_svanflaqftu1nycobjhe019h` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=370 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SignUpConfirmation`
--

LOCK TABLES `SignUpConfirmation` WRITE;
/*!40000 ALTER TABLE `SignUpConfirmation` DISABLE KEYS */;
INSERT INTO `SignUpConfirmation` VALUES (357,'793e12ca-3c5c-4502-ac1f-7977c2342905',913),(358,'f7c4e098-14ca-4a1b-af53-882a68371b6c',914),(359,'b14ab4f2-28ad-4fad-91f9-2f3ec5bab65a',915),(360,'ccfb2374-68a6-43c1-aedb-153d133e1ffe',916),(361,'1ddd58b5-90a9-4ca8-bafb-b0afb76dd744',917),(362,'aa9ed84e-2ecc-4023-a599-0b5e7ceef336',918),(363,'4d3aa320-ca1b-4d44-996f-8eafcb036a50',919),(364,'b1478313-134f-4c41-93ac-366017646afc',920),(365,'787a629c-961e-4d06-ba47-3db9f6fb6973',921),(366,'bb0ddb2e-a6c8-4df5-a2f0-cecacd48ab29',922),(367,'7dda36a7-74e7-40cd-9534-9c3d3736aaac',923),(368,'508c7fa6-02d8-40be-a6fe-a1922832f033',1028),(369,'98206a6b-6771-48bf-8570-f5540d01bcb8',1029);
/*!40000 ALTER TABLE `SignUpConfirmation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-14 15:57:10
